Algorithms
==========

.. toctree::
   :maxdepth: 2
   
   data_structures
   dynamic_programming
   factorization
   math
   random
   searching
   shuffling
   sorting
