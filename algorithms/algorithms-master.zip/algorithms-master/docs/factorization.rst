Factorization
=============

.. automodule:: algorithms.factorization.fermat
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: algorithms.factorization.pollard_rho
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: algorithms.factorization.trial_division
    :members:
    :undoc-members:
    :show-inheritance:
