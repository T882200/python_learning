Math
====

.. automodule:: algorithms.math.approx_cdf
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: algorithms.math.extended_gcd
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: algorithms.math.lcm
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: algorithms.math.primality_test
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: algorithms.math.sieve_atkin
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: algorithms.math.sieve_eratosthenes
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: algorithms.math.std_normal_pdf
    :members:
    :undoc-members:
    :show-inheritance:
