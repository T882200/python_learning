Random
======

.. automodule:: algorithms.random.mersenne_twister
    :members:
    :undoc-members:
    :show-inheritance:
