Searching
=========

.. automodule:: algorithms.searching.binary_search
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: algorithms.searching.bmh_search
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: algorithms.searching.depth_first_search
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: algorithms.searching.kmp_search
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: algorithms.searching.rabinkarp_search
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: algorithms.searching.ternary_search
    :members:
    :undoc-members:
    :show-inheritance:
