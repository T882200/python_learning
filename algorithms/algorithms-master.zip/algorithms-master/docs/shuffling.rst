Shuffling
=========

.. automodule:: algorithms.shuffling.knuth
    :members:
    :undoc-members:
    :show-inheritance:
